using UnityEngine.AI;
using UnityEngine;
using System;

[RequireComponent(typeof(NavMeshAgent))]
public class Enemy : MonoBehaviour
{
    // Agent allows enemy to move 
    protected NavMeshAgent agent;

    // Enemies will use the same animation tree so I animate them in the base class
    public Animator anim;
    protected bool moving = false;

    [SerializeField] protected float attackDistance;
    protected bool attacking = false;
    [SerializeField] protected Transform target;

    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        anim = GetComponentInChildren<Animator>();

        agent.stoppingDistance = attackDistance;
    }

    protected virtual void Start()
    {
        
    }

    protected virtual void Update()
    {
        Movement();
        UpdateAnim();
    }

    // Allowing the enemies to move in different ways 
    protected virtual void Movement(){}

    // Call the enemy's attack animation
    protected virtual void Attack()
    {
        if (attacking) { return; }
        attacking = true;
        anim.SetTrigger("attack");
    }

    public void FinishAttack()
    {
        attacking = false;
    }

    protected virtual void LookAtTarget()
    {
        Vector3 lookPos = target.position - transform.position;
        lookPos.y = 0;
        Quaternion rotation = Quaternion.LookRotation(lookPos);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, 0.2f);
    }

    protected virtual void UpdateAnim()
    {
        anim.SetBool("moving", moving);
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(transform.position, attackDistance);
    }

}

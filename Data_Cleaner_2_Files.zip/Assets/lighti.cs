using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lighti : MonoBehaviour
{
    public void testFunction()
    {
        Debug.Log("Function Fired");
    }
}

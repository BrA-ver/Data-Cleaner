1. Created 2 enemy npcs using polymorphism
    - Melee Enemy:
        runs to the player and attacks when they reach 
    - Ranged Enemy: 
        Runs to the player up to a cetain distance and throws fireballs at the player
    - Enemy scripts are in Scripts / Enemy

2. Created 3 VFX graphs:
    - Fire:
        Used to make projectiles
    - Checkpoint:
        Used to make checkpoints
    - Explosion:
        Used to make projectile impacts
    - Graphs are in VFX folder

3. I have 2 scriptable objects:
    - They hold data for the different types of projectiles and thier shooting force
    - This makes it easier to re-assign prefabs and values
    - Scriptable objects are in Scripts / Scriptable Objects / Bullet Shooter

